package bitcamp.java106.pms;

import java.util.Scanner;

public abstract class Description {
    public abstract void add(Scanner sc, String[] questions);
    public abstract void get();
    public abstract String getBase();
}